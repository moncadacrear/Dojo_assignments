import React from 'react';
import './App.css';
import ToDolist from "./components/ToDolist"
import Header from "./components/Header"
import PersonCard from "./components/PersonCard"

function App() {
  return (
    <div className="App">

      {/* <Header firstname = {"alex"} lastname = {"solis"}/> */}
      <PersonCard firstName = {"Jane"} lastName ={"Doe"} Age = {45} HairColor ={"black"}/>

      <PersonCard firstName = {"John"} lastName ={"Smith"} Age = {88} HairColor ={"Brown"}/>

      <PersonCard firstName = {"Millard"} lastName ={"Fillmore"} Age = {50} HairColor ={"Brown"}/>

      <PersonCard firstName = {"Maria"} lastName ={"Smith"} Age = {62} HairColor ={"Brown"}/>

    </div>
  );
}

export default App;
