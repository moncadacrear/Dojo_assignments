import React,{Component} from 'react';


class ToDolist extends Component{







    render(){
        return(
            <div>
                <ul>
                    <li>learn react</li>
                    <li>climb Mt. Everest</li>
                    <li>Run a marathon </li>
                    <li> feed the dogs </li>
                </ul>

            </div>
        )
    }
}

export default ToDolist; 


